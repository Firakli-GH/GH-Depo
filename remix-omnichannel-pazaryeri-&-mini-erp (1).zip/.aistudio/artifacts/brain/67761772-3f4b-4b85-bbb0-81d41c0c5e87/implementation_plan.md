# Pazaryeri Operatör Paneli, Kademeli Sipariş Akışı & Sorunlular Masası Uygulama Planı (Revize)

Bu plan, kullanıcının geri bildirimleri ve pazaryeri entegrasyonu standartları doğrultusunda revize edilmiştir. Ana ekran sadeleştirmesi, operatör kokpiti, kalem altı doğrudan notlar, kapsamlı sipariş detay ekranı, müşteri mesajı uyarıları ve aynı müşteriye ait çoklu sipariş (ayrı barkod) ayrımını içerir.

---

## 1. Mimari Kararlar ve Revizyon Özeti

| Alan | Kullanıcı Talebi & Karar | Uygulama Detayı |
| :--- | :--- | :--- |
| **Bileşen Reçetesi Gösterimi** | Ana liste görünümünde olmamalı, sadece Detay ekranında olmalı | Sipariş kartında/satırında reçete bileşenleri gösterilmez. Yalnızca ürünün adı, görseli ve sipariş adedi yer alır. Reçete dökümü **"Sipariş Detayı"** ekranında tüm detaylarla özetlenir. |
| **Kapsamlı Sipariş Detayı** | Detay butonu ile açılan ekran tüm sipariş bilgilerini özetlemeli | Müşteri verileri, sevk/fatura adresi, kargo kampanya kodu, dondurulmuş ürün reçetesi (BOM), dondurulmuş kargo desi/maliyet bilgisi, kalem notları tek modallık özet panelde sunulur. |
| **Kalem Düzeyinde Notlar** | Buton veya sayaç değil, kalemin altında doğrudan alt bilgi olarak yer almalı | Her kalem satırının altında `border-t` ile ayrılmış, açık gri/sarı zeminli okunabilir not metni yer alır (örn: *"Not: Depodan hasarlı ürün değiştirildi - 10.10.2026 14:10"*). Çift tıkla veya düzenle ikonuyla anında düzenlenebilir. |
| **Müşteri Mesajı İkonu** | Siparişle ilgili müşteri mesajı varsa sipariş bazında mesaj ikonu olmalı | Sipariş başlığında mavi/kehribar `MessageSquare` ikonu yer alır; üzerine gelindiğinde (tooltip) veya tıklandığında müşterinin sipariş notu anında okunur. |
| **Sipariş Kalem Hiyerarşisi** | Sipariş bir kaç kalemden oluşabilir; kalemler sipariş altında toplanmalı | Tek sipariş ID ve tek kargo kampanya kodu altında müşterinin aldığı tüm ürünler hiyerarşik olarak listelenir (örn: 1x Kolonya, 5x Zeytin). |
| **Aynı Müşterinin Ayrı Siparişleri** | Aynı müşteri aynı adrese farklı siparişler vermişse ayrı barkodla kargo edilir | Sistem aynı müşteri veya adrese ait birden çok sipariş tespit ettiğinde sipariş başlığına *"Aynı Müşteriye Ait 2 Ayrı Sipariş (Ayrı Kargo Barkodu)"* uyarısı koyar. |
| **Navigasyon Sadeleştirmesi** | Sık kullanılanlar açık, diğerleri kapalı menü | Üst barda **Genel Bakış (Kokpit)**, **Sipariş Yönetimi** ve **Ürün Yönetimi** sabit; diğer 7 modül **"Diğer Modüller"** açılır menüsünde toplanır. |
| **Kademeli Akış & Sorunlular** | Siparişlerin aşamalı ilerlemesi ve sorunluların ayrılması | 6 Aşamalı Kademeli Sekme (`Yeniler & Onaylılar` $\to$ `Faturalandı` $\to$ `Kargolandı` $\to$ `Teslim Edildi` $\to$ `Tamamlandı` $\to$ `Sorunlular`). Canlı durum akışı ve kargo durdurma uyarısı. |

---

## 2. Kullanıcı Arayüzü & Tasarım Prensipleri

1. **Navigasyon Çubuğu:**
   - Sabit Sol/Orta Sekmeler: `Operatör Kokpiti`, `Sipariş Yönetimi`, `Ürün Yönetimi`.
   - Sağ Taraf Açılır Menü (`Diğer Modüller`): Kargo & Barem Masası, Desi Mutabakatı, Fiyat & Kâr Simülatörü, Mini ERP Depo, Müşteri Soruları, Finans, Entegrasyon Ayarları.
2. **Sipariş Kartı / Satırı Görünümü:**
   - **Başlık Satırı:** Pazaryeri Logosu (Trendyol, Hepsiburada, N11), Sipariş No, Kargo Kampanya/Takip Kodu, Kargo Şirketi Logosu (TEX, Aras, HepsiJet vb.), Durum Rozeti, İl-İlçe (İstanbul için yeşil `Kendi Dağıtımımız (İstanbul)` rozeti), varsa **Müşteri Mesajı İkonu**, varsa **Aynı Müşteriye Ait Ek Sipariş Uyarısı**, "Detay" butonu ve Hızlı Eylem butonları (*Onayla*, *Faturalandır*, *Kargola* vb.).
   - **Gövde (Alt Kalemler Hiyerarşisi):**
     * Mini ürün görseli (40x40px).
     * Ürün Adı ve Varyant bilgisi.
     * Adet çarpanı (`x1`, `x5`).
     * Birim & Toplam Tutar (`font-mono tabular-nums`).
     * **Doğrudan Kalem Alt Bilgisi (Not):** Kalemin hemen altında açık gri/amber zemin üzerinde doğrudan okunan not metni (örneğin: *"Tedarik: Yarın sabah depoya giriş yapılacak"*).
3. **Kapsamlı Sipariş Detay Modalı (`OrderDetailModal`):**
   - Müşteri Adı, Telefon, E-posta, Teslimat ve Fatura Adresi.
   - Sipariş Tarihi, Pazaryeri Sipariş No, Kargo Paketi Kampanya Kodu.
   - Kalemlerin reçete dökümü (BOM Snapshot - örn: Kolonya 4'lü paket için 4x 150ml Şişe + 4x Kapak + 1x Kutu).
   - Dondurulmuş Kargo Parametreleri (Hesaplanan Desi, Seçilen Firma, Tahmini Barem Bedeli, Gerçekleşen Navlun).
   - Müşteri Mesajı tam metni.
   - Operatör Notları geçmişi ve yeni not ekleme alanı.
4. **Sorunlular Masası:**
   - Sevkiyat öncesi iptal olan siparişler için belirgin **DURDUR: Kargoya Verme!** kırmızı uyarısı.
   - İade nedenleri analizi (hasarlı, cayma, eksik ürün) ve pazaryeri itiraz süresi takibi.
   - Temin edilemeyen/stokta biten kalemlerin işaretlenmesi.

---

## 3. Veri Modeli Değişiklikleri (`src/types/index.ts`)

```typescript
// Kalem Düzeyinde Not Modeli
export interface OrderItemNote {
  id: string;
  itemId: string;
  author: string;
  content: string;
  category: 'supply' | 'cargo' | 'return' | 'general';
  createdAt: string;
}

// OrderItem Zenginleştirmesi
export interface OrderItem {
  id: string;
  productId: string;
  title: string;
  quantity: number;
  unitPrice: number;
  imageUrl?: string;
  itemDesi?: number;
  itemNote?: string; // Doğrudan kalemin altında görünen not metni
  notesHistory?: OrderItemNote[];
}

// Order Zenginleştirmesi
export interface Order {
  // Mevcut alanlar...
  customerMessage?: string; // Varsa mesaj ikonu tetikler
  hasMultipleOrdersForCustomer?: boolean; // Aynı müşteriye ait başka sipariş var uyarısı
  relatedOrderNumbers?: string[]; // Aynı müşterinin diğer sipariş no'ları
  deliveryCityType?: 'istanbul_own_fleet' | 'other_city';
  issueType?: 'pre_shipment_cancel' | 'delivery_failed' | 'return_requested' | 'supply_shortage' | 'manual_flag';
  issueDisputeDeadline?: string;
  issueResolutionStatus?: 'investigating' | 'disputed' | 'cancelled_stopped' | 'resolved';
}
```

---

## 4. Uygulama Adımları

1. **Veri Modeli & Mock Veri Güncellemesi (`types/index.ts` & `initialData.ts`):**
   - Alt kalemlerde görseller, adetler ve kalem altı notları (`itemNote`) tanımlama.
   - Müşteri mesajı olan siparişler (`customerMessage`) ve aynı müşteriye ait birden çok sipariş durumu (`hasMultipleOrdersForCustomer: true`) ekleme.
2. **Navigasyon Sadeleştirmesi (`Header.tsx` & `App.tsx`):**
   - Üst barda sadece `Genel Bakış (Kokpit)`, `Sipariş Yönetimi`, `Ürün Yönetimi` sekmelerini açık tutma.
   - Diğer tüm sayfaları (Kargo Masası, Mutabakat, Fiyat Simülatörü, Mini ERP, Finans, Sorular, Ayarlar) şık bir `Diğer Modüller` açılır menüsünde toplama.
3. **Operatör Karar Destek Kokpiti (`DashboardView.tsx`):**
   - Günlük & Aylık sipariş adedi ve ciro KPI özetleri.
   - 4 Eylem Kutusu: Cevap bekleyen sorular (SLA), Kargosu gecikenler, Sevkiyat öncesi iptal yakalama alarmları, Kargo desi/ücret farkları.
4. **Sipariş Gösterimi & Hiyerarşik Liste (`OrdersView.tsx`):**
   - Reçeteyi ana listeden kaldırma.
   - Sipariş başlığında: Pazaryeri ikonu, Kargo firması ikonu, Durum ikonu, Müşteri Mesajı ikonu (tooltip/modal), Aynı Müşteriye Ait Ek Sipariş uyarısı, İstanbul Kendi Dağıtımımız yeşil etiketi.
   - Sipariş altında gruplanmış kalemler: Mini görsel, Ürün adı, xAdet, Tutar ve hemen altında açık metin olarak **Kalem Notu Alt Bilgisi**.
   - Hızlı durum ilerletme butonları (*Onayla $\to$ Faturalandır $\to$ Kargola $\to$ Teslim Et $\to$ Tamamla*).
5. **Kapsamlı Sipariş Detay Modalı (`OrderDetailModal.tsx`):**
   - Detay butonuna tıklandığında açılan tam teşekküllü özet: Müşteri bilgileri, kargo dondurulmuş desisi ve baremi, bileşen reçetesi (BOM Snapshot), adresler, loglar ve kalem notu düzenleyici.
6. **Kademeli Akış & Sorunlular Masası (`ProblemOrdersDesk.tsx` veya entegre sekme):**
   - 6 Aşamalı Kademeli Filtreleme (*Yeniler & Onaylılar $\to$ Faturada $\to$ Kargoda $\to$ Teslim Edildi $\to$ Tamamlandı $\to$ Sorunlular*).
   - Sorunlular sekmesinde: Sevkiyat öncesi iptal durdurma uyarısı, iade itiraz dökümü ve pazar yeri itirazı oluşturma.
7. **Derleme & Doğrulama (`compile_applet`):**
   - TypeScript derleme testleri ve tüm etkileşimlerin doğrulanması.

---

## 5. Doğrulama Kriterleri

- Ana listede gereksiz reçete kalabalığı olmadan yalnızca ürün adı, görseli ve adedi görülür.
- Detay butonuna basıldığında tüm reçete, kargo dondurma ve sipariş bilgileri eksiksiz açılır.
- Her ürün kaleminin altında girilen not doğrudan okunur ve anında güncellenebilir.
- Müşteri mesajı olan siparişlerde mesaj ikonu görünür ve tıklandığında mesaj okunur.
- Aynı müşteriye ait birden fazla sipariş varsa açıkça ayrı barkod uyarısı verilir.
- Navigasyon menüsünde sadece 3 ana sekme açık, diğerleri açılır menüdedir.
- Sıfır derleme hatasıyla uygulama kusursuz çalışır.
