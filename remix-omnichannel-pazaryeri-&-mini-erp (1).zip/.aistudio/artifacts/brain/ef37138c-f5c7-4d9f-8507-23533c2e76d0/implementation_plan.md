# Kategori Ağacı, Marka Tablosu, Pazaryeri Eşleme ve Sağ Tık Ürün Açma Motoru

Ana ürünlerimizi bağladığımız hiyerarşik kategori ağacı ve üretici marka mimarisinin kurulması, yalnızca ürünlerimizle eşleşen pazaryeri kategori ve marka verilerini işleyen akıllı eşleme yapısı, Trendyol ve Hepsiburada'nın beklediği zorunlu ek niteliklerin (attributes) yönetimi ve ürün tablosunda sağ tık (context menu) ile çalışan çoklu/tekil pazaryerine ürün açma motoru planıdır.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Entegratör Mimari Yaklaşımı (Entegra / Sopyo / ChannelEngine Deneyimi)**:
> 1. **Hedefli Eşleme (Targeted Mapping)**: Pazaryerlerinin yüz binlerce kategori ve marka verisini gereksiz yere indirmek yerine, **sadece kataloğumuzdaki ürünlerin kategorileri ve markaları** pazaryerleriyle sorgulanıp eşlenir.
> 2. **Sağ Tık (Context Menu) & Çift Giriş Noktası**: Operatör hem ürün listesinde istediği satırlara sağ tıklayarak (Context Menu) "Trendyol'a Gönder", "Hepsiburada'ya Gönder" veya "Tüm Kanallara Gönder" diyebilecek, hem de tekil ürün detay kartında kanal bazlı ek nitelikleri düzenleyip yayına alabilecektir.
> 3. **Ek Bilgiler (Mandatory Attributes) Doğrulama Kalkanı**: Trendyol ve Hepsiburada'nın ürün kabul şartı olan kategori bazlı ek nitelikler (Hacim, Renk, Beden, Menşei vb.) eksikse ürün API'ye fırlatılmadan önce kullanıcıya hızlı tamamlama sihirbazı sunulur.

- **Onaylanan Kapsam**:
  - Hiyerarşik Kategori Ağacı (`MasterCategory`) ve Marka Tablosu (`MasterBrand`) varlıkları.
  - Pazaryeri Kategori & Marka Eşleme Masası (Otomatik eşleşme önerisi ve tek tık onay).
  - Ürün Ek Bilgileri ve Nitelik Motoru (Trendyol & Hepsiburada dinamik şemaları).
  - Masaüstü ERP benzeri Sağ Tık (Context Menu) bileşeni ve Toplu Seçim Çubuğu.
  - Pazaryerine Ürün Açma ve Asenkron Batch Gönderim Motoru.

---

## 1. Overview & Core Concept

Bir e-ticaret satıcısının ürünlerini birden fazla pazaryerine hatasız açabilmesi için ürünün:
1. Merkezi bir kategoriye (Örn: *Kozmetik > Kolonya*) ve markaya (*Marmara*) bağlı olması,
2. Bu kategorinin Trendyol'daki karşılığı (*Kişisel Bakım > Kolonya*, Kategori Id: 412) ve Hepsiburada'daki karşılığı (*Sağlık & Kozmetik > Kolonyalar*, Id: 1802) ile eşlenmiş olması,
3. Pazaryerinin zorunlu kıldığı ek niteliklerin (*Hacim: 400 ml*, *Cinsiyet: Unisex*, *Koku Türü: Limon*) ürün üzerinde tanımlı olması gerekir.

Bu geliştirme, operatörün katalog listesinde istediği 1 veya 10 ürünü seçip **sağ tıklayarak** tek seferde Trendyol ve Hepsiburada'ya göndermesini sağlar.

---

## 2. User Experience & Visual Design

`Plus Jakarta Sans` arayüz fontu, `JetBrains Mono` veri fontları, dark slate tema ve sıfır pill disiplini ile şu arayüz bileşenleri oluşturulacaktır:

### A. Sağ Tık Bağlam Menüsü (Context Menu)
- Ürün tablosunda herhangi bir ürün satırına veya çoklu seçilmiş ürün grubuna sağ tıklandığında açılan şık, klavye/fare duyarlı B2B context menu:
  - `🚀 Pazaryerlerine Gönder...` (Alt menü: *Trendyol*, *Hepsiburada*, *N11*, *PttAVM*, *Tüm Kanallar*)
  - `📋 Yayınlanabilirlik Denetimi (Readiness Check)` (Eksik barkod, görsel, nitelik kontrolü)
  - `🏷️ Kategori & Marka Eşlemesini Gör`
  - `📑 Yeni Klon İlan Oluştur`
  - `✏️ Ürün Detayını Aç`

### B. Pazaryeri Ürün Açma & Yayınlama Sihirbazı (`ProductDispatchModal.tsx`)
- Sağ tıklandığında veya üstteki "Pazaryerine Gönder" butonuna basıldığında açılan modal:
  - **Aşama 1: Yayınlanabilirlik Skoru & Zorunlu Ek Bilgiler**:
    - Ürünün seçilen kanal için eksik bilgileri var mı? (Örn: Trendyol "Hacim" alanı boşsa modal içinden anında seçilebilir açılır kutu).
  - **Aşama 2: Satış ve Fiyat Parametreleri**:
    - Kanal bazlı komisyon, kargo baremi ve sevk termin süresi teyidi.
  - **Aşama 3: Asenkron Gönderim & Batch API Takibi**:
    - "Gönder" butonuna basıldığında pazaryeri REST API formatında JSON gövdesi oluşturulur, `batchRequestId` alınır ve ürünün kanal ilanları (`ChannelListingProduct`) anında güncellenir.

### C. Kategori Ağacı ve Marka Yönetim Masası (`CategoryBrandMappingView.tsx`)
- Sol Panel: Hiyerarşik Kategori Ağacı (Açılır/kapanır klasör yapısı, ürün sayıları).
- Sağ Panel:
  - Üst Sekme 1: **Kategori Eşleme Matrisi**: Bizim kategorimiz ↔ Trendyol Kategori ID / Hepsiburada Kategori ID.
  - Üst Sekme 2: **Marka Eşleme Matrisi**: Bizim üretici markamız ↔ Pazaryeri Marka Kodu.
  - Üst Sekme 3: **Zorunlu Nitelik Kuralları**: Kategoriye bağlı zorunlu özelliklerin varsayılan şablonları.

### D. Tekil Ürün Detay Modalı Entegrasyonu
- `MainProductCatalogView` içindeki ürün kartında ve düzenleme penceresinde "Pazaryeri Ek Nitelikleri (Attributes)" sekmesi eklenir.

---

## 3. Veri Modeli ve Mimari Yapı

```
┌────────────────────────────────────────────────────────────────────────┐
│                   MERKEZİ VE PAZARYERİ VERİ İLİŞKİSİ                  │
└────────────────────────────────────────────────────────────────────────┘
                 ┌──────────────────────────────────────┐
                 │ MasterCategory (Hiyerarşik Ağaç)     │
                 │ - Id, Name, Code, ParentId, Path     │
                 └──────────────────┬───────────────────┘
                                    │ 1:N
                 ┌──────────────────▼───────────────────┐
                 │ MainProduct (Ana Ürün Katalog)       │
                 │ - MasterBarcode, MasterCode, Title   │
                 │ - CategoryId, BrandId                │
                 │ - AttributeValues: Record<string,any>│
                 └──────────┬───────────────────────┬───┘
                            │                       │
           1:N              │                       │ 1:N
┌───────────────────────────▼───────┐     ┌─────────▼────────────────────────┐
│ CategoryMarketplaceMapping        │     │ BrandMarketplaceMapping          │
│ - MasterCategoryId                │     │ - MasterBrandId                  │
│ - Channel (trendyol, hepsiburada) │     │ - Channel                        │
│ - RemoteCategoryId, RemotePath    │     │ - RemoteBrandId, RemoteBrandName │
│ - MandatoryAttributes: [...]      │     └──────────────────────────────────┘
└──────────────────┬────────────────┘
                   │
                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│ ProductDispatchEngine (Sağ Tık / Toplu Gönderim Motoru)                │
│ 1. Validate: EAN + Images + Mapped Category + Mapped Brand            │
│ 2. Compose: Trendyol/HB Vendor Payload with Extra Attributes           │
│ 3. Execute: Batch Request API Call                                     │
│ 4. Track: Return Batch ID & Create ChannelListingProduct               │
└────────────────────────────────────────────────────────────────────────┘
```

### TypeScript Veri Yapıları:
- `MasterCategory`: `id`, `name`, `code`, `parentId`, `slug`, `level`, `productCount`
- `MasterBrand`: `id`, `name`, `code`, `originCountry`, `logoUrl`
- `CategoryMarketplaceMapping`: `masterCategoryId`, `channel`, `remoteCategoryId`, `remoteCategoryName`, `remoteCategoryPath`, `mandatoryAttributes: CategoryAttributeDefinition[]`
- `BrandMarketplaceMapping`: `masterBrandId`, `channel`, `remoteBrandId`, `remoteBrandName`, `isVerified`
- `CategoryAttributeDefinition`: `attributeId`, `name`, `code`, `required`, `allowCustom`, `values: { id: number, name: string }[]`
- `ProductMarketplaceAttributeValue`: `attributeId`, `attributeName`, `valueId`, `customValue`

---

## 4. Adım Adım Uygulama Planı

1. **Tip Tanımları (`src/types/categoryBrand.ts` ve `src/types/index.ts`)**:
   - `MasterCategory`, `MasterBrand`, `CategoryMarketplaceMapping`, `BrandMarketplaceMapping`, `CategoryAttributeDefinition`, `ProductDispatchJob` arayüzlerini tanımlama.
2. **Örnek Veri Seti (`src/data/categoryBrandData.ts`)**:
   - Kolonya, gıda/zeytinyağı, elektronik, bilgisayar aksesuarları gibi ürünlerimize uygun 3 kademeli kategori ağacı ve üretici markalarını tanımlama.
   - Trendyol ve Hepsiburada'nın gerçek kategori ID'leri ve zorunlu alanlarını içeren hazır eşleme veritabanı.
3. **Pazaryeri Ürün Açma Servisi (`src/services/productDispatchService.ts`)**:
   - Seçilen ana ürünlerin yayınlanabilirlik kontrolü (Readiness check).
   - Trendyol `createProductsBatch` ve Hepsiburada `merchant/listings/create` gövdelerinin dinamik niteliklerle derlenmesi.
   - Batch istek simülasyonu ve `ChannelListingProduct` üretimi.
4. **Sağ Tık Bağlam Menüsü Bileşeni (`src/components/ContextMenu.tsx`)**:
   - Fare sağ tık pozisyonunda (x, y) açılan, klavyeden ESC ve dış tıklama ile kapanan, z-index korumalı yüksek kaliteli B2B context menu.
5. **Ürün Açma Sihirbazı Modalı (`src/components/ProductDispatchModal.tsx`)**:
   - Seçilen ürünleri Trendyol/Hepsiburada için doğrulayan, eksik ek nitelikleri (attributes) anında doldurma imkanı sunan ve tek tıkla gönderen modal.
6. **Kategori & Marka Eşleme Masası Görünümü (`src/components/CategoryBrandMappingView.tsx`)**:
   - Ürünlerimizin kategorilerini ve markalarını pazaryerleri ile eşleyen, otomatik öneri sunan ve filtreleyen yönetim ekranı.
7. **Ana Ürün Kataloğu Entegrasyonu (`src/components/MainProductCatalogView.tsx`)**:
   - Çoklu ürün seçimi onay kutuları (checkbox).
   - Sağ tık menüsü bağlantısı (tekil ve çoklu seçim desteği).
   - Üst eylem çubuğunda "Pazaryerine Gönder" ve "Kategori/Marka Eşleme" kısayolları.
   - Ürün detayında kategori, marka ve ek nitelikler görünümü.
8. **Doğrulama & Test**:
   - `compile_applet` ile tip ve derleme doğrulaması; sağ tıkla Trendyol ve Hepsiburada'ya ürün aktarımı akışının test edilmesi.
